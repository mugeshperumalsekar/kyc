package com.ponsun.kyc.Master.QuestionType.request;

import lombok.Data;

@Data
public class UpdateQuestionTypeRequest extends AbstractQuestionTypeRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
