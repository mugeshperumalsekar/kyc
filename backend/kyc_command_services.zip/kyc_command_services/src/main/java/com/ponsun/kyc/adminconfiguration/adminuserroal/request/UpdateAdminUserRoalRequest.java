package com.ponsun.kyc.adminconfiguration.adminuserroal.request;

import lombok.Data;

@Data
public class UpdateAdminUserRoalRequest extends AbstractAdminUserRoalBaseRequest {
    @Override
    public String toString() {return super.toString(); }

}