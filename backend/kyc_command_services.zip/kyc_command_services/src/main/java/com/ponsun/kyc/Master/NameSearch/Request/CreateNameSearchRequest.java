package com.ponsun.kyc.Master.NameSearch.Request;

public class CreateNameSearchRequest {
}
