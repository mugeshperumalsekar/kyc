package com.ponsun.kyc.Master.NameSearch.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NameSearchRepository extends JpaRepository<NameSearch,Integer> {
}
