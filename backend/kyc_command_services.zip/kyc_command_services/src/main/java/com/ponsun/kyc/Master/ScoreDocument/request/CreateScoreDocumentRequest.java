package com.ponsun.kyc.Master.ScoreDocument.request;

import lombok.Data;

@Data
public class CreateScoreDocumentRequest extends AbstractScoreDocumentRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
