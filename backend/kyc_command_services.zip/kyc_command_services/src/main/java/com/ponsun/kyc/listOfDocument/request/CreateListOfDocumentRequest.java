package com.ponsun.kyc.listOfDocument.request;

import lombok.Data;

@Data
public class CreateListOfDocumentRequest extends AbstractListOfDocumentRequest {
   @Override
   public String toString(){ return super.toString();}
}
