package com.ponsun.kyc.Master.ApplicantForm.request;

import lombok.Data;

@Data
public class CreateApplicantFormRequest extends AbstractApplicantFormRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
