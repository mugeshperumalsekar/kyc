package com.ponsun.kyc.FilesStorage.data;

public class FileStorageDataValidator {
}
