package com.ponsun.kyc.Master.AnswerFieldType.request;

import lombok.Data;

@Data
public class AbstractAnswerFieldTypeRequest {
    private String name;
    private Integer uid;
    private Integer euid;

}
