package com.ponsun.kyc.adminconfiguration.admingroup.request;

import lombok.Data;

@Data
public class UpdateAdmingroupRequest extends AbstractAdmingroupBaseRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
