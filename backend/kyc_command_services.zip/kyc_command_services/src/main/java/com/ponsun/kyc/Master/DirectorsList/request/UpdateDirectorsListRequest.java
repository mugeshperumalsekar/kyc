package com.ponsun.kyc.Master.DirectorsList.request;

import lombok.Data;

@Data
public class UpdateDirectorsListRequest extends AbstractDirectorsListRequest {
    @Override
    public String toString(){ return super.toString();}
}
