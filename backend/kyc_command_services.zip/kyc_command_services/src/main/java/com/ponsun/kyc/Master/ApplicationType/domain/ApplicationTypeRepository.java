package com.ponsun.kyc.Master.ApplicationType.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicationTypeRepository extends JpaRepository<ApplicationType,Integer> {
}
