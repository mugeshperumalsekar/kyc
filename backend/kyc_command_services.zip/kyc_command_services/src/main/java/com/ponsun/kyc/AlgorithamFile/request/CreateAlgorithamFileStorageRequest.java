package com.ponsun.kyc.AlgorithamFile.request;

import lombok.Data;

@Data
public class CreateAlgorithamFileStorageRequest extends AbstractAlgorithamFileStorageRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
