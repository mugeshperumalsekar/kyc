package com.ponsun.kyc.Master.NameSearch.Request;

import lombok.Data;

@Data
public class AbstractNameSearchRequest {
    private String question;
    private String answer;
}
