package com.ponsun.kyc.AlgorithamFile.request;

import lombok.Data;

@Data
public class UpdateAlgorithamFileStorageRequest extends AbstractAlgorithamFileStorageRequest {
    @Override
    public String toString() {
        return super.toString();
    }

}
