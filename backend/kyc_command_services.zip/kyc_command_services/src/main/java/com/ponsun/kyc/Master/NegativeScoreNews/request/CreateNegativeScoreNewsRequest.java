package com.ponsun.kyc.Master.NegativeScoreNews.request;

import lombok.Data;

@Data
public class CreateNegativeScoreNewsRequest extends AbstractNegativeScoreNewsRequest{
    @Override
    public String toString(){
        return super.toString();
    }

}
