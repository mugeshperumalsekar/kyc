package com.ponsun.kyc.Master.ApplicantFormDetails.request;

import lombok.Data;

@Data
public class CreateApplicantFormDetailsRequest extends UpdateApplicantFormDetailsRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
