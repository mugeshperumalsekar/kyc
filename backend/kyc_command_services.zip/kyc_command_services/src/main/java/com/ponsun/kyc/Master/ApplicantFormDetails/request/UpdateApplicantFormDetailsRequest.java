package com.ponsun.kyc.Master.ApplicantFormDetails.request;

import lombok.Data;

@Data
public class UpdateApplicantFormDetailsRequest extends AbstractApplicantFormDetailsRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
