package com.ponsun.kyc.Master.NegativeScoreNews.data;

public class NegativeScoreNewsValidator {
}
