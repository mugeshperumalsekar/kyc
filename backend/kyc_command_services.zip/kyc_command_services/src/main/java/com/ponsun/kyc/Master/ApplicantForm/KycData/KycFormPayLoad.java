package com.ponsun.kyc.Master.ApplicantForm.KycData;

import lombok.Data;

@Data
public class KycFormPayLoad {
    private KycFormDto kycFormDto;
}
