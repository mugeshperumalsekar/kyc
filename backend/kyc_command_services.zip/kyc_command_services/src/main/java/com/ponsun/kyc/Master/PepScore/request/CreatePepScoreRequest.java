package com.ponsun.kyc.Master.PepScore.request;

import lombok.Data;

@Data
public class CreatePepScoreRequest extends AbstractPepScoreRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
