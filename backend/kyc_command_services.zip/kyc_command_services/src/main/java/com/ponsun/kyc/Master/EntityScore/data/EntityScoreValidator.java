package com.ponsun.kyc.Master.EntityScore.data;

public class EntityScoreValidator {
}
