package com.ponsun.kyc.Master.ApplicantForm.dto;

import lombok.Data;

@Data
public class ApplicantFormPayload {
    private ApplicantFormDto applicantFormDto;

}
