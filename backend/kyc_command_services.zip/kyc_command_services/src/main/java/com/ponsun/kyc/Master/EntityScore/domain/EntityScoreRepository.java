package com.ponsun.kyc.Master.EntityScore.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EntityScoreRepository extends JpaRepository<EntityScore,Integer> {
}
