package com.ponsun.kyc.letterHeadUpload.request;

import lombok.Data;

@Data
public class UpdateLetterHeadUploadRequest extends AbstractLetterHeadUploadRequest {
    @Override
    public String toString(){ return super.toString();}
}

