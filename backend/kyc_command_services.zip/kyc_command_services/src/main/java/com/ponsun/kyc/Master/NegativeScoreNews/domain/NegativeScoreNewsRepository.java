package com.ponsun.kyc.Master.NegativeScoreNews.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NegativeScoreNewsRepository extends JpaRepository<NegativeScoreNews, Integer> {
}
