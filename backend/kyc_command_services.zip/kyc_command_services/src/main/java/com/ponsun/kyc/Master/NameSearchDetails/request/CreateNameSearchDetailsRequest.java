package com.ponsun.kyc.Master.NameSearchDetails.request;

import lombok.Data;

@Data
public class CreateNameSearchDetailsRequest extends AbstractNameSearchDetailsRequest{
    @Override
    public String toString() {return super.toString();}
}
