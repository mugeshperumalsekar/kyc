package com.ponsun.kyc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PONSUN_KYC_Application {
	public static void main(String[] args) {
		SpringApplication.run(PONSUN_KYC_Application.class, args);
	}
}