package com.ponsun.kyc.Master.ApplicantForm.KycData;

import lombok.Data;
@Data

public class KycAnswerData {
    private String answer;
    private double score;
    private String additionalDetails;

    public KycAnswerData(String answer, double score,String additionalDetails) {
        this.answer = answer;
        this.score= score;
        this.additionalDetails = additionalDetails;
    }
    public static KycAnswerData newInstance(String answer, double score,String additionalDetails){
        return new KycAnswerData(answer,score,additionalDetails);
    }
}
