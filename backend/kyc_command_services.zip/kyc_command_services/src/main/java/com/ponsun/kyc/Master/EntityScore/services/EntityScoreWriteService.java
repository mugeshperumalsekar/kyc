package com.ponsun.kyc.Master.EntityScore.services;


import java.util.List;

public class EntityScoreWriteService {
}
