package com.ponsun.kyc.FilesStorage.request;

public class UpdateFileStorageRequest {
    @Override
    public String toString() {
        return super.toString();
    }

}
