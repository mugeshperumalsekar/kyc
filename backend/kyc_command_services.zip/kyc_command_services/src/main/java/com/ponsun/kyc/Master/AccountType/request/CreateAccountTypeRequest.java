package com.ponsun.kyc.Master.AccountType.request;

import lombok.Data;

@Data
public class CreateAccountTypeRequest extends AbstractAccountTypeRequest {
    @Override
    public String toString(){ return super.toString();}
}
