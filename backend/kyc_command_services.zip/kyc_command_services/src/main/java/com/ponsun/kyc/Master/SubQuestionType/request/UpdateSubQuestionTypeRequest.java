package com.ponsun.kyc.Master.SubQuestionType.request;

import lombok.Data;

@Data
public class UpdateSubQuestionTypeRequest extends AbstractSubQuestionTypeRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
