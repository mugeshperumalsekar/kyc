package com.ponsun.kyc.Master.DeclarationForm.request;

import lombok.Data;

@Data
public class UpdateDeclarationFormRequest extends AbstractDeclarationFormRequest {
    @Override
    public String toString(){ return super.toString();}
}
