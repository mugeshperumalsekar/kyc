package com.ponsun.kyc.Master.DirectorsSignAuthority.request;

import lombok.Data;

@Data
public class CreateDirectorsSignAuthorityRequest extends AbstractDirectorsSignAuthorityRequest{
    @Override
    public String toString(){ return super.toString();}
}
