package com.ponsun.kyc.Master.ScoreCalculation.request;

import lombok.Data;

@Data
public class UpdateScoreCalculationRequest extends AbstractScoreCalculationRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
