package com.ponsun.kyc.Master.ClientView.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientViewRepository extends JpaRepository<ClientView, Integer> {
}
