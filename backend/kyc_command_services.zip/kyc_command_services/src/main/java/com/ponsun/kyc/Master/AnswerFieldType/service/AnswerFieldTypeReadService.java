package com.ponsun.kyc.Master.AnswerFieldType.service;

import com.ponsun.kyc.Master.AnswerFieldType.domain.AnswerFieldType;

import java.util.List;

public interface AnswerFieldTypeReadService {
    List<AnswerFieldType> fetchAll();

}
