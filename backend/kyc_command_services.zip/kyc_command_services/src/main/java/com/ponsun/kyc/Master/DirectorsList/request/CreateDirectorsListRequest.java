package com.ponsun.kyc.Master.DirectorsList.request;

import lombok.Data;

@Data
public class CreateDirectorsListRequest extends AbstractDirectorsListRequest {
    @Override
    public String toString(){ return super.toString();}
}
