package com.ponsun.kyc.Master.AnswerFieldType.request;

import lombok.Data;

@Data
public class CreateAnswerFieldTypeRequest extends AbstractAnswerFieldTypeRequest {
    @Override
    public String toString(){ return super.toString();}

}
