package com.ponsun.kyc.AlgorithamFile.data;

public class AlgorithamFileStorageDataValidator {
}
