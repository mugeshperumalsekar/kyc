package com.ponsun.kyc.Master.PepScore.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PepScoreRepository extends JpaRepository<PepScore,Integer> {
}
