package com.ponsun.kyc.Master.ApplicationType.request;

import lombok.Data;

@Data
public class CreateApplicationTypeRequest extends AbstractApplicationTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
