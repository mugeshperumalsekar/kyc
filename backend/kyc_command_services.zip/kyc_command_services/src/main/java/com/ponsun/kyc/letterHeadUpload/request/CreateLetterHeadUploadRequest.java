package com.ponsun.kyc.letterHeadUpload.request;

import lombok.Data;

@Data
public class CreateLetterHeadUploadRequest extends AbstractLetterHeadUploadRequest {
    @Override
    public String toString(){ return super.toString();}
}
