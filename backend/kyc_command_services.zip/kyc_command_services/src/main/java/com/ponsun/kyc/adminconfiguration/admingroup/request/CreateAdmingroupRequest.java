package com.ponsun.kyc.adminconfiguration.admingroup.request;

import lombok.Data;

@Data
public class CreateAdmingroupRequest extends AbstractAdmingroupBaseRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
