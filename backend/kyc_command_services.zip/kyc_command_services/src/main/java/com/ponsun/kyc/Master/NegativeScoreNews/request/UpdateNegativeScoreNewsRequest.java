package com.ponsun.kyc.Master.NegativeScoreNews.request;

import lombok.Data;

@Data
public class UpdateNegativeScoreNewsRequest extends AbstractNegativeScoreNewsRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
