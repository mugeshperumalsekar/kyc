package com.ponsun.kyc.Master.QuestionType.request;

import lombok.Data;

@Data
public class CreateQuestionTypeRequest extends AbstractQuestionTypeRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
