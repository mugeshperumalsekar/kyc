package com.ponsun.kyc.Master.PepScore.data;

public class PepScoreValidator {
}
