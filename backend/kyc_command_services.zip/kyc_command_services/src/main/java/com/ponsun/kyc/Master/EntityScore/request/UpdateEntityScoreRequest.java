package com.ponsun.kyc.Master.EntityScore.request;

import lombok.Data;

@Data
public class UpdateEntityScoreRequest extends AbstractEntityScoreRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
