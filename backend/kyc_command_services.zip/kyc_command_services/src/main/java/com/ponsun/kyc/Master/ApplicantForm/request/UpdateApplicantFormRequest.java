package com.ponsun.kyc.Master.ApplicantForm.request;

import lombok.Data;

@Data
public class UpdateApplicantFormRequest extends AbstractApplicantFormRequest{
    @Override
    public String toString(){
        return super.toString();
    }
}
