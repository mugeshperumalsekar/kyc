package com.ponsun.kyc.Master.DirectorsSignAuthority.request;

import lombok.Data;

@Data
public class UpdateDirectorsSignAuthorityRequest extends AbstractDirectorsSignAuthorityRequest{
    @Override
    public String toString(){ return super.toString();}
}
