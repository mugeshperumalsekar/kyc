package com.ponsun.kyc.Master.ScoreDocument.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ScoreDocumentRepository extends JpaRepository<ScoreDocument,Integer> {
}
