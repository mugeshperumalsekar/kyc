package com.ponsun.kyc.Master.ApplicationType.request;

import lombok.Data;

@Data
public class UpdateApplicationTypeRequest extends AbstractApplicationTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
