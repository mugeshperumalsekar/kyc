package com.ponsun.kyc.Master.SubQuestionType.request;

import lombok.Data;

@Data
public class CreateSubQuestionTypeRequest extends AbstractSubQuestionTypeRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
