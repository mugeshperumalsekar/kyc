package com.ponsun.kyc.Master.AnswerType.request;

import lombok.Data;

@Data
public class UpdateAnswerTypeRequest extends AbstractAnswerTypeRequest {
    @Override
    public String toString(){ return super.toString();}
}
