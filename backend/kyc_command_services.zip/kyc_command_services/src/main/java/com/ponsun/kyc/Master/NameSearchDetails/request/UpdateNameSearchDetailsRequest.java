package com.ponsun.kyc.Master.NameSearchDetails.request;

import lombok.Data;

@Data
public class UpdateNameSearchDetailsRequest extends AbstractNameSearchDetailsRequest{
    @Override
    public String toString() {return super.toString();}
}
