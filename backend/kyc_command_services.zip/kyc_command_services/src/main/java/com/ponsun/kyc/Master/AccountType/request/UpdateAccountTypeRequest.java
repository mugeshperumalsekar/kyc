package com.ponsun.kyc.Master.AccountType.request;

import lombok.Data;

@Data
public class UpdateAccountTypeRequest extends AbstractAccountTypeRequest {
    @Override
    public String toString(){ return super.toString();}

}
