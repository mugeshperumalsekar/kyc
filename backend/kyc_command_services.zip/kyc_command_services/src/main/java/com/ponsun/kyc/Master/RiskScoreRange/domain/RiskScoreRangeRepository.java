package com.ponsun.kyc.Master.RiskScoreRange.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskScoreRangeRepository extends JpaRepository<RiskScoreRange,Integer> {
}
