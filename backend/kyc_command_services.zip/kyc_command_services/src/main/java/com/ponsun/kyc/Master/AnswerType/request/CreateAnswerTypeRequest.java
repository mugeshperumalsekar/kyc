package com.ponsun.kyc.Master.AnswerType.request;

import lombok.Data;

@Data
public class CreateAnswerTypeRequest extends AbstractAnswerTypeRequest {
    @Override
    public String toString(){ return super.toString();}

}
