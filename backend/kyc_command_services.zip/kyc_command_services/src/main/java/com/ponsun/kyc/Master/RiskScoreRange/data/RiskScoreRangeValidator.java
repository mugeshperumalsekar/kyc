package com.ponsun.kyc.Master.RiskScoreRange.data;

public class RiskScoreRangeValidator {
}
