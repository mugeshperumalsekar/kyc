touch .gitignore

cd existing_repo
git remote add origin https://gitlab.com/LocalDateTime_services/LocalDateTime_command_services.git
git branch -M main
git push -uf origin main
